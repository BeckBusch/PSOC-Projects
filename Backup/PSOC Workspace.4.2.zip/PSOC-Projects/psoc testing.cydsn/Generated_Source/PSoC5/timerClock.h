/*******************************************************************************
* File Name: timerClock.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_timerClock_H)
#define CY_CLOCK_timerClock_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_20 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void timerClock_Start(void) ;
void timerClock_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void timerClock_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void timerClock_StandbyPower(uint8 state) ;
void timerClock_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 timerClock_GetDividerRegister(void) ;
void timerClock_SetModeRegister(uint8 modeBitMask) ;
void timerClock_ClearModeRegister(uint8 modeBitMask) ;
uint8 timerClock_GetModeRegister(void) ;
void timerClock_SetSourceRegister(uint8 clkSource) ;
uint8 timerClock_GetSourceRegister(void) ;
#if defined(timerClock__CFG3)
void timerClock_SetPhaseRegister(uint8 clkPhase) ;
uint8 timerClock_GetPhaseRegister(void) ;
#endif /* defined(timerClock__CFG3) */

#define timerClock_Enable()                       timerClock_Start()
#define timerClock_Disable()                      timerClock_Stop()
#define timerClock_SetDivider(clkDivider)         timerClock_SetDividerRegister(clkDivider, 1u)
#define timerClock_SetDividerValue(clkDivider)    timerClock_SetDividerRegister((clkDivider) - 1u, 1u)
#define timerClock_SetMode(clkMode)               timerClock_SetModeRegister(clkMode)
#define timerClock_SetSource(clkSource)           timerClock_SetSourceRegister(clkSource)
#if defined(timerClock__CFG3)
#define timerClock_SetPhase(clkPhase)             timerClock_SetPhaseRegister(clkPhase)
#define timerClock_SetPhaseValue(clkPhase)        timerClock_SetPhaseRegister((clkPhase) + 1u)
#endif /* defined(timerClock__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define timerClock_CLKEN              (* (reg8 *) timerClock__PM_ACT_CFG)
#define timerClock_CLKEN_PTR          ((reg8 *) timerClock__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define timerClock_CLKSTBY            (* (reg8 *) timerClock__PM_STBY_CFG)
#define timerClock_CLKSTBY_PTR        ((reg8 *) timerClock__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define timerClock_DIV_LSB            (* (reg8 *) timerClock__CFG0)
#define timerClock_DIV_LSB_PTR        ((reg8 *) timerClock__CFG0)
#define timerClock_DIV_PTR            ((reg16 *) timerClock__CFG0)

/* Clock MSB divider configuration register. */
#define timerClock_DIV_MSB            (* (reg8 *) timerClock__CFG1)
#define timerClock_DIV_MSB_PTR        ((reg8 *) timerClock__CFG1)

/* Mode and source configuration register */
#define timerClock_MOD_SRC            (* (reg8 *) timerClock__CFG2)
#define timerClock_MOD_SRC_PTR        ((reg8 *) timerClock__CFG2)

#if defined(timerClock__CFG3)
/* Analog clock phase configuration register */
#define timerClock_PHASE              (* (reg8 *) timerClock__CFG3)
#define timerClock_PHASE_PTR          ((reg8 *) timerClock__CFG3)
#endif /* defined(timerClock__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define timerClock_CLKEN_MASK         timerClock__PM_ACT_MSK
#define timerClock_CLKSTBY_MASK       timerClock__PM_STBY_MSK

/* CFG2 field masks */
#define timerClock_SRC_SEL_MSK        timerClock__CFG2_SRC_SEL_MASK
#define timerClock_MODE_MASK          (~(timerClock_SRC_SEL_MSK))

#if defined(timerClock__CFG3)
/* CFG3 phase mask */
#define timerClock_PHASE_MASK         timerClock__CFG3_PHASE_DLY_MASK
#endif /* defined(timerClock__CFG3) */

#endif /* CY_CLOCK_timerClock_H */


/* [] END OF FILE */
