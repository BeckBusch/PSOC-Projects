/*******************************************************************************
* File Name: switchPin.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_switchPin_H) /* Pins switchPin_H */
#define CY_PINS_switchPin_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "switchPin_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 switchPin__PORT == 15 && ((switchPin__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    switchPin_Write(uint8 value);
void    switchPin_SetDriveMode(uint8 mode);
uint8   switchPin_ReadDataReg(void);
uint8   switchPin_Read(void);
void    switchPin_SetInterruptMode(uint16 position, uint16 mode);
uint8   switchPin_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the switchPin_SetDriveMode() function.
     *  @{
     */
        #define switchPin_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define switchPin_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define switchPin_DM_RES_UP          PIN_DM_RES_UP
        #define switchPin_DM_RES_DWN         PIN_DM_RES_DWN
        #define switchPin_DM_OD_LO           PIN_DM_OD_LO
        #define switchPin_DM_OD_HI           PIN_DM_OD_HI
        #define switchPin_DM_STRONG          PIN_DM_STRONG
        #define switchPin_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define switchPin_MASK               switchPin__MASK
#define switchPin_SHIFT              switchPin__SHIFT
#define switchPin_WIDTH              1u

/* Interrupt constants */
#if defined(switchPin__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in switchPin_SetInterruptMode() function.
     *  @{
     */
        #define switchPin_INTR_NONE      (uint16)(0x0000u)
        #define switchPin_INTR_RISING    (uint16)(0x0001u)
        #define switchPin_INTR_FALLING   (uint16)(0x0002u)
        #define switchPin_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define switchPin_INTR_MASK      (0x01u) 
#endif /* (switchPin__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define switchPin_PS                     (* (reg8 *) switchPin__PS)
/* Data Register */
#define switchPin_DR                     (* (reg8 *) switchPin__DR)
/* Port Number */
#define switchPin_PRT_NUM                (* (reg8 *) switchPin__PRT) 
/* Connect to Analog Globals */                                                  
#define switchPin_AG                     (* (reg8 *) switchPin__AG)                       
/* Analog MUX bux enable */
#define switchPin_AMUX                   (* (reg8 *) switchPin__AMUX) 
/* Bidirectional Enable */                                                        
#define switchPin_BIE                    (* (reg8 *) switchPin__BIE)
/* Bit-mask for Aliased Register Access */
#define switchPin_BIT_MASK               (* (reg8 *) switchPin__BIT_MASK)
/* Bypass Enable */
#define switchPin_BYP                    (* (reg8 *) switchPin__BYP)
/* Port wide control signals */                                                   
#define switchPin_CTL                    (* (reg8 *) switchPin__CTL)
/* Drive Modes */
#define switchPin_DM0                    (* (reg8 *) switchPin__DM0) 
#define switchPin_DM1                    (* (reg8 *) switchPin__DM1)
#define switchPin_DM2                    (* (reg8 *) switchPin__DM2) 
/* Input Buffer Disable Override */
#define switchPin_INP_DIS                (* (reg8 *) switchPin__INP_DIS)
/* LCD Common or Segment Drive */
#define switchPin_LCD_COM_SEG            (* (reg8 *) switchPin__LCD_COM_SEG)
/* Enable Segment LCD */
#define switchPin_LCD_EN                 (* (reg8 *) switchPin__LCD_EN)
/* Slew Rate Control */
#define switchPin_SLW                    (* (reg8 *) switchPin__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define switchPin_PRTDSI__CAPS_SEL       (* (reg8 *) switchPin__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define switchPin_PRTDSI__DBL_SYNC_IN    (* (reg8 *) switchPin__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define switchPin_PRTDSI__OE_SEL0        (* (reg8 *) switchPin__PRTDSI__OE_SEL0) 
#define switchPin_PRTDSI__OE_SEL1        (* (reg8 *) switchPin__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define switchPin_PRTDSI__OUT_SEL0       (* (reg8 *) switchPin__PRTDSI__OUT_SEL0) 
#define switchPin_PRTDSI__OUT_SEL1       (* (reg8 *) switchPin__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define switchPin_PRTDSI__SYNC_OUT       (* (reg8 *) switchPin__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(switchPin__SIO_CFG)
    #define switchPin_SIO_HYST_EN        (* (reg8 *) switchPin__SIO_HYST_EN)
    #define switchPin_SIO_REG_HIFREQ     (* (reg8 *) switchPin__SIO_REG_HIFREQ)
    #define switchPin_SIO_CFG            (* (reg8 *) switchPin__SIO_CFG)
    #define switchPin_SIO_DIFF           (* (reg8 *) switchPin__SIO_DIFF)
#endif /* (switchPin__SIO_CFG) */

/* Interrupt Registers */
#if defined(switchPin__INTSTAT)
    #define switchPin_INTSTAT            (* (reg8 *) switchPin__INTSTAT)
    #define switchPin_SNAP               (* (reg8 *) switchPin__SNAP)
    
	#define switchPin_0_INTTYPE_REG 		(* (reg8 *) switchPin__0__INTTYPE)
#endif /* (switchPin__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_switchPin_H */


/* [] END OF FILE */
